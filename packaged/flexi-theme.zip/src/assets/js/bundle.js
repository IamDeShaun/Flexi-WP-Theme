//import "jquery";
import $ from 'jquery';