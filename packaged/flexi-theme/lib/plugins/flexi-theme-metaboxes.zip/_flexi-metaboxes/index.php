<?php
/*
Plugin Name: flexi-theme metaboxes
Plugin URI:
Description: Adding Metaboxes for flexi-theme
Version:     1.0.0
Author:      DeShaun Jones
Author URI:  http://deshaunjones.com
License:      GPL2
License URI:
Text Domain:   flexi-theme-metaboxes
Domain Path:  /languages

*/

if( !defined('WPINC')) {
  die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');






?>